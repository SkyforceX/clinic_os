from django.urls import path
from . import views

app_name = 'health_record'

urlpatterns = [
    # path('ds-benh-nhan/', views.get_patient_list, name='get_patient_list'),
    path('', views.patient_report, name='patient_report'),
    path('api', views.view_patient_report_api_vnpt, name='view_patient_report_api_vnpt'),

    path('api_patient_report', views.api_patient_report, name='api_patient_report'), # api vnpt
    # path('api/patient-list/', views.api_get_patient_list, name='api_get_patient_list'), # api vnpt

    #===== local module upload/view healthresult =====#
    path("upload/", views.upload_patient_document, name="upload_patient_document"),
    path("ajax/patients/", views.ajax_patients_by_company, name="ajax_patients_by_company"),
    path("ajax/doc-url/", views.ajax_get_patient_doc_url, name="ajax_get_patient_doc_url"),
    path("api/patient-docs/<int:doc_id>/delete/", views.delete_patient_document, name="delete_patient_document"),
]
