# apps/health_record/forms.py
from django import forms
from django.core.exceptions import ValidationError

from .models import PatientDocument
from apps.patients.models import Patient

MAX_MB = 25

class PatientDocumentForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop("user", None)
        super().__init__(*args, **kwargs)

        # Mặc định: chưa có company -> để queryset rỗng và disable
        self.fields["patient"].queryset = Patient.objects.none()

        # Nếu đang edit (instance đã có company) hoặc có POST với company -> nạp lọc theo company
        company_id = None
        if "company" in self.data and self.data.get("company"):
            company_id = self.data.get("company") or None
        # khi edit ínstance
        elif self.instance and self.instance.pk:
            company_id = self.instance.company_id

        if company_id:
            self.fields["patient"].queryset = (
                Patient.objects.filter(company_id=company_id).order_by("ho_ten")
            )

    class Meta:
        model = PatientDocument
        fields = ["company", "patient", "doc_type", "visit_date", "file", "is_final", "patient_name"]
        widgets = {
            "visit_date": forms.DateInput(attrs={"type": "date", "class": "d-block date-picker", "placeholder": "dd/mm/yyyy"}),
        }
        labels = {
            "company": "Công ty",
            "patient": "Họ tên khách hàng",
            "doc_type": "Loại tài liệu",
            "visit_date": "Ngày khám/Ngày trả kết quả",
            "file": "Tệp PDF kết quả",
            "is_final": "Khoá kết quả",
            "patient_name": "Tên bệnh nhân (hiển thị)",
        }

    def clean(self):
        cleaned = super().clean()
        company = cleaned.get("company")
        patient = cleaned.get("patient")
        doc_type = cleaned.get("doc_type")
        visit_date = cleaned.get("visit_date")

        if not all([company, patient, doc_type, visit_date]):
            return cleaned  # thiếu dữ liệu, để các validator khác xử lý

        # Kiểm tra bệnh nhân thuộc đúng công ty (an toàn server-side)
        if getattr(patient, "company_id", None) != company.id:
            self.add_error("patient", ValidationError("Bệnh nhân không thuộc công ty đã chọn."))

        # Chặn overwrite nếu KHÔNG phải superadmin
        # Record trùng khóa (patient + visit_date + doc_type) đã tồn tại?
        exists_qs = PatientDocument.objects.filter(
            patient=patient,
            visit_date=visit_date,
            doc_type=doc_type,
        )
        if self.instance and self.instance.pk:
            exists_qs = exists_qs.exclude(pk=self.instance.pk)

        if exists_qs.exists():
            # chỉ superuser mới được overwrite
            if not (self.user and self.user.is_superuser):
                raise ValidationError(f"❌ File đã tồn tại với ngày khám {visit_date}.")

        return cleaned
