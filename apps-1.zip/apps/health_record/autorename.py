import os

root_dir = r"D:\data\results\by-patient"  # đường dẫn gốc

# Mapping tên cần đổi
rename_map = {
    "clinical.pdf": "periodic_book.pdf",
    "paraclinical.pdf": "blood.pdf",
}

count = 0
skipped = 0

for dirpath, dirnames, filenames in os.walk(root_dir):
    for filename in filenames:
        lower_name = filename.lower()
        if lower_name in rename_map:
            old_path = os.path.join(dirpath, filename)
            new_path = os.path.join(dirpath, rename_map[lower_name])

            try:
                if not os.path.exists(new_path):
                    os.rename(old_path, new_path)
                    print(f"✅ Đổi: {old_path} → {new_path}")
                    count += 1
                else:
                    print(f"⚠️ Bỏ qua (đã có {rename_map[lower_name]}): {old_path}")
                    skipped += 1
            except Exception as e:
                print(f"❌ Lỗi khi đổi {old_path}: {e}")

print(f"\nHoàn tất: {count} file đã đổi, {skipped} file bị bỏ qua.")
