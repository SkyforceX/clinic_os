# apps/health_record/models.py
import uuid
from django.db import migrations, models
from apps.core.storages import ResultsStorage
from apps.core.paths import build_patient_doc_path

results_storage = ResultsStorage()

def map_old_types(apps, schema_editor):
    PatientDocument = apps.get_model("health_record", "PatientDocument")
    PatientDocument.objects.filter(doc_type="clinical").update(doc_type="periodic-book")
    PatientDocument.objects.filter(doc_type="paraclinical").update(doc_type="imaging")

class PatientDocument(models.Model):
    class DocType(models.TextChoices):
        BLOOD = "blood", "Kết quả máu"
        IMAGING = "imaging", "Kết quả chẩn đoán hình ảnh"
        PERIODIC_BOOK = "periodic-book", "Sổ khám sức khỏe định kỳ"

    id = models.BigAutoField(primary_key=True)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)
    
    company = models.ForeignKey("organizations.Company", on_delete=models.PROTECT, related_name="patient_docs")
    contract = models.ForeignKey("booking.HealthContract", on_delete=models.PROTECT, related_name="patient_docs",
                                 null=True, blank=True)
    patient = models.ForeignKey("patients.Patient", on_delete=models.PROTECT, related_name="documents")

    patient_name = models.CharField(max_length=150, blank=True)

    doc_type   = models.CharField(max_length=20, choices=DocType.choices)
    visit_date = models.DateField()

    # File PDF (ghi đè nếu cùng ngày + loại)
    file = models.FileField(upload_to=build_patient_doc_path, storage=results_storage)
    file_size = models.BigIntegerField(null=True, blank=True)
    content_type = models.CharField(max_length=100, default="application/pdf")

    is_final = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "healthrecord_patientdocument"
        ordering = ["-visit_date", "-created_at"]
        # Một BN, trong 1 ngày, cho mỗi loại, chỉ 1 record → nếu upload lại thì update/ghi đè
        constraints = [
            models.UniqueConstraint(
                fields=["patient", "visit_date", "doc_type"],
                name="uniq_doc_per_patient_per_day_per_type",
            )
        ]
        indexes = [
            models.Index(fields=["company", "contract", "patient", "visit_date"]),
            models.Index(fields=["uuid"]),
        ]

    def save(self, *args, **kwargs):
        if not self.patient_name:
            self.patient_name = getattr(self.patient, "ho_ten", "") or getattr(self.patient, "full_name", "") or ""
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.get_doc_type_display()} - {self.patient_name} ({self.visit_date:%d/%m/%Y})"

    @property
    def download_filename(self):
        return f"{self.patient_name or 'Benh-nhan'}_{self.doc_type}_{self.visit_date:%Y%m%d}.pdf"
