from pathlib import Path
from urllib.parse import urlparse

import requests
from django.conf import settings
from django.db import transaction
from django.utils.dateparse import parse_date
from datetime import date
from collections import defaultdict
from types import SimpleNamespace
import json

from django.views.decorators.http import require_POST

from apps.authentication.utils import patient_access_required
# API/service đã có sẵn
from apps.external_api.services import fetch_patient_by_code  # quét theo tháng, dùng ddMMyyyy
from apps.external_api.utils import parse_dob                # parse "22/10/1981" -> date
from apps.external_api.client import get_patient_report

from django.utils.text import slugify

from apps.patients.models import Patient
from .utils import *
import mimetypes
from django.contrib.auth.decorators import login_required, permission_required
from django.http import JsonResponse, FileResponse, Http404
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.contrib import messages
from .models import *
from .forms import PatientDocumentForm

#============ patient report ==============#
def _build_patient_folder(patient_code: str) -> Path:
    """
    Tìm thư mục bệnh nhân theo chuẩn:
      by-patient/<bnCODE-uuid...>
    - Ưu tiên khớp prefix đầy đủ (vd: 'bn00002311*')
    - Fallback: slugify(patient_code) loại '-' để tăng khả năng khớp
    - Cuối cùng: trả về base/patient_code (dù có thể chưa tồn tại)
    """
    base = Path(getattr(settings, "RESULTS_ROOT")) / "by-patient"
    if not base.exists():
        return base / patient_code

    safe_code = slugify(patient_code).replace("-", "")
    # Thử các pattern khả dĩ
    candidates = list(base.glob(f"{patient_code}*")) + list(base.glob(f"{safe_code}*"))
    return candidates[0] if candidates else (base / patient_code)


# def _to_result_url(file_path: Path) -> str:
#     """Chuyển đường dẫn thật thành URL /media/results/..."""
#     rel_path = file_path.relative_to(Path(settings.RESULTS_ROOT))
#     return f"{settings.RESULTS_URL}/{rel_path.as_posix()}"

def _to_result_url(file_path: str | Path | None) -> str | None:
    """
    Nhận str/Path/None và trả về URL /media/results/...
    - Nếu đã là URL (http/https) → trả thẳng.
    - Nếu là đường dẫn tương đối → hiểu là nằm trong RESULTS_ROOT.
    - Nếu nằm ngoài RESULTS_ROOT → trả None
    """
    if not file_path:
        return None

    s = str(file_path)
    # Đã là URL sẵn
    if s.startswith(("http://", "https://")):
        return s
    # Đã là URL kết quả
    if s.startswith(str(settings.RESULTS_URL)):
        return s

    root = Path(settings.RESULTS_ROOT).resolve()
    p = Path(s)

    # Nếu là relative path (ví dụ: "results/2025/11/12/file.pdf") → ghép vào root
    if not p.is_absolute():
        p = root / p

    # Chuẩn hóa rồi tính tương đối với RESULTS_ROOT
    try:
        rel = p.resolve().relative_to(root)
    except Exception:
        return None  # hoặc: return s nếu muốn hiển thị nguyên xi

    base = str(settings.RESULTS_URL).rstrip("/")
    return f"{base}/{rel.as_posix()}"


def _collect_patient_reports(patient_code: str):
    """
    Duyệt cấu trúc:
      data/results/by-patient/<folder>/YYYY/YYYYMMDD/{blood|imaging|periodic_book}.pdf
    Trả về list dict dùng cho UI:
      - year, date_str, display_date
      - blood_url, imaging_url, periodic_book_url
    Hỗ trợ legacy: clinical.pdf → periodic_book, paraclinical.pdf → blood
    """
    root = _build_patient_folder(patient_code)
    results = []
    if not root.exists():
        return results

    # Ưu tiên tên mới trước, sau đó đến legacy (tương thích ngược)
    FILE_CANDIDATES = {
        "blood": ("blood.pdf", "paraclinical.pdf"),
        "imaging": ("imaging.pdf",),
        "periodic_book": ("periodic_book.pdf", "clinical.pdf"),
    }

    def first_existing(date_dir: Path, names: tuple[str, ...]) -> str | None:
        for name in names:
            p = date_dir / name
            if p.exists():
                return _to_result_url(p)
        return None

    # Duyệt năm (YYYY)
    for year_dir in sorted(root.glob("[0-9]" * 4)):
        if not year_dir.is_dir():
            continue

        # Duyệt ngày (YYYYMMDD)
        for date_dir in sorted(year_dir.glob("[0-9]" * 8)):
            if not date_dir.is_dir():
                continue

            blood_url = first_existing(date_dir, FILE_CANDIDATES["blood"])
            imaging_url = first_existing(date_dir, FILE_CANDIDATES["imaging"])
            periodic_book_url = first_existing(date_dir, FILE_CANDIDATES["periodic_book"])

            # Nếu ngày đó có ít nhất một file hợp lệ thì đưa vào kết quả
            if blood_url or imaging_url or periodic_book_url:
                d = date_dir.name  # "YYYYMMDD"
                item = {
                    "year": year_dir.name,
                    "date_str": d,
                    "display_date": f"{d[6:8]}/{d[4:6]}/{d[0:4]}",
                    "blood_url": blood_url,
                    "imaging_url": imaging_url,
                    "periodic_book_url": periodic_book_url,
                }
                results.append(item)

    # Mới nhất lên trước
    results.sort(key=lambda x: (x["year"], x["date_str"]), reverse=True)
    return results


def _collect_patient_reports_all_by_id(*, patient_id: int):
    """
    Trả về list dict:
      {year, date_str(YYYYMMDD), display_date(dd/mm/YYYY),
       blood_url, imaging_url, periodic_book_url}
    Lấy TẤT CẢ tài liệu của BN theo DB, không lọc công ty/khung ngày.
    """
    qs = (
        PatientDocument.objects
        .filter(
            patient_id=patient_id,
            doc_type__in=[
                PatientDocument.DocType.BLOOD,
                PatientDocument.DocType.IMAGING,
                PatientDocument.DocType.PERIODIC_BOOK,
            ],
        )
        .order_by('visit_date', 'doc_type', '-created_at', '-id')
        .only('id', 'file', 'visit_date', 'doc_type', 'created_at')
    )

    by_date = defaultdict(dict)
    for doc in qs.iterator():
        dkey = f"{doc.visit_date:%Y%m%d}"
        kind = (
            'blood' if doc.doc_type == PatientDocument.DocType.BLOOD else
            'imaging' if doc.doc_type == PatientDocument.DocType.IMAGING else
            'periodic_book'
        )

        # Lấy path vật lý hoặc file.url, chuyển sang URL chuẩn qua _to_result_url
        file_path = getattr(doc.file, 'path', None) or getattr(doc.file, 'name', None)
        file_url = _to_result_url(file_path) if file_path else None

        # Chỉ giữ file đầu tiên mỗi loại trong ngày (mới nhất theo ordering)
        if kind not in by_date[dkey]:
            by_date[dkey][kind] = file_url

    results = []
    for dkey, kinds in by_date.items():
        results.append({
            "year": dkey[:4],
            "date_str": dkey,
            "display_date": f"{dkey[6:8]}/{dkey[4:6]}/{dkey[0:4]}",
            "blood_url": kinds.get("blood"),
            "imaging_url": kinds.get("imaging"),
            "periodic_book_url": kinds.get("periodic_book"),
        })

    # Mới nhất trước
    results.sort(key=lambda x: (x["year"], x["date_str"]), reverse=True)
    return results
@patient_access_required
def patient_report(request):
    # Check đăng nhập
    patient_id = request.session.get("patient_id")
    if not patient_id:
        messages.error(request, "Bạn cần đăng nhập để xem thông tin.")
        return redirect("authentication:patient_login")

    patient = getattr(request, "patient", None)
    if not patient:
        # nếu đang lưu sẵn patient trong session, load từ DB:
        patient = Patient.objects.filter(id=patient_id).first()
        if not patient:
            messages.error(request, "Không tìm thấy bệnh nhân.")
            return redirect("authentication:patient_login")

    reports = _collect_patient_reports_all_by_id(patient_id=patient_id)

    return render(request, "health_record/patient_report.html", {
        "patient": patient,
        "reports": json.dumps(reports, ensure_ascii=False),
    })

# ============ Upload cho nhân viên ============
@login_required
def upload_patient_document(request):
    if request.method == "POST":
        # 1) Bắt 3 khóa từ POST để tìm sẵn bản ghi
        patient_id = request.POST.get("patient")
        visit_date = request.POST.get("visit_date")  # dạng YYYY-MM-DD từ input date
        doc_type   = request.POST.get("doc_type")

        existing = None
        if patient_id and visit_date and doc_type:
            # Note: Django có thể parse str "YYYY-MM-DD" trong filter DateField
            existing = PatientDocument.objects.filter(
                patient_id=patient_id,
                visit_date=visit_date,
                doc_type=doc_type,
            ).first()

        # 2) Khởi tạo form với instance=existing (nếu có) để form hiểu là UPDATE
        form = PatientDocumentForm(
            request.POST, request.FILES,
            user=request.user,
            instance=existing  # <-- VERY IMPORTANT
        )

        if form.is_valid():
            with transaction.atomic():
                # Khóa hàng nếu đã tồn tại để tránh race condition
                obj = None
                if existing:
                    obj = (PatientDocument.objects
                           .select_for_update()
                           .get(pk=existing.pk))


                # Lấy dữ liệu sạch
                data = form.cleaned_data
                f = data["file"]

                is_new = None  # flag mặc định là file mới
                if obj is None:
                    # Tạo mới
                    obj = form.save(commit=False)
                    is_new = obj
                else:
                    # Cập nhật các trường không thuộc file
                    obj.company = data["company"]
                    if data.get("patient_name"):
                        obj.patient_name = data["patient_name"]
                    obj.is_final = data["is_final"]
                    # (Các field khóa đã đúng do form bound instance)

                # ---- Ghi đè file cũ an toàn ----
                old_name = obj.file.name if obj.file else None
                if old_name:
                    try:
                        obj.file.storage.delete(old_name)
                    except Exception:
                        pass
                    # lưu file mới vào cùng đường dẫn cũ (nếu muốn giữ nguyên path)
                    obj.file.save(old_name, f, save=False)
                else:
                    obj.file = f

                # Metadata
                obj.file_size = getattr(f, "size", None)
                obj.content_type = getattr(f, "content_type", "application/pdf") or "application/pdf"

                # Bổ sung patient_name tự fill nếu rỗng (model.save cũng có xử lý)
                if not obj.patient_name:
                    obj.patient_name = getattr(obj.patient, "ho_ten", "") or getattr(obj.patient, "full_name", "") or ""

                obj.save()

            if is_new:
                messages.success(request, "✅ Đã lưu PDF mới thành công.")
            else:
                messages.info(request, "♻️ File đã tồn tại — đã ghi đè PDF cũ thành công.")
            return redirect(f"{reverse('health_record:upload_patient_document')}?company={form.cleaned_data['company'].id}")

        # form lỗi -> render lại
        return render(request, "health_record/staff/upload_patient_document.html", {"form": form})

    # GET
    initial = {}
    company_id = request.GET.get("company")
    if company_id:
        initial["company"] = company_id
    form = PatientDocumentForm(initial=initial, user=request.user)
    return render(request, "health_record/staff/upload_patient_document.html", {"form": form})

@login_required
@require_POST
def delete_patient_document(request, doc_id):
    # kiểm tra quyền:
    # if not request.user.has_perm("healthrecord.delete_patientdocument"): return HttpResponseForbidden()
    obj = get_object_or_404(PatientDocument, id=doc_id)

    # kiểm tra thuộc công ty/hợp đồng hiện tại để tránh xoá nhầm:
    # company_id = request.POST.get("company_id")
    # contract_id = request.POST.get("contract_id")
    # if company_id and str(obj.company_id) != str(company_id): return HttpResponseForbidden("Sai công ty")
    # if contract_id and str(obj.contract_id) != str(contract_id): return HttpResponseForbidden("Sai hợp đồng")

    with transaction.atomic():
        # Xoá file vật lý (nếu còn)
        try:
            if obj.file:
                obj.file.delete(save=False)
        except Exception:
            # không fail cứng vì có thể file đã mất
            pass
        obj.delete()

    return JsonResponse({"ok": True})

#====== tải cho BN =======#
def download_document(request, uuid):
    obj = get_object_or_404(PatientDocument, uuid=uuid)

    f = obj.file
    if not f or not f.storage.exists(f.name):
        raise Http404("Không tìm thấy file PDF.")
    resp = FileResponse(f.open("rb"), content_type=obj.content_type or "application/pdf")
    resp["Content-Disposition"] = f'attachment; filename="{obj.download_filename}"'
    return resp

#================= API VNPT ==================#
@patient_access_required
def api_patient_report(request):
    patient_code = request.session.get("patient_code")
    try:
        reports = get_patient_report(patient_code)
        return JsonResponse({'success': True, 'reports': reports})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


def _fmt_dmy(d):
    """date -> dd/mm/yyyy (dùng để hiển thị)"""
    try:
        return d.strftime("%d/%m/%Y")
    except Exception:
        return ""


@patient_access_required
def view_patient_report_api_vnpt(request):
    """
    Hiển thị hồ sơ + danh sách phiếu của BN thật theo mã BN.
    - Ưu tiên DB nội bộ; nếu không có -> gọi VNPT
    - Lấy danh sách phiếu qua viewreport (đã ẩn 'Tóm tắt bệnh án')
    """
    patient_code = request.session.get("patient_code")
    d_from = settings.PATIENT_SEARCH_START  # "01012025"
    d_to = date.today()

    # 1) Thử DB nội bộ trước
    local = Patient.objects.filter(ma_bn=patient_code).first()

    if local:
        # Tạo patient object cho template
        patient = SimpleNamespace(
            id=local.id,
            ho_ten=local.ho_ten,
            ngay_sinh=_fmt_dmy(local.ngay_sinh),
            gioi_tinh=local.gioi_tinh,
            phone=local.phone,
            dia_chi=local.dia_chi or "",
            ma_bn=local.ma_bn,
        )
    else:
        # 2) Không có trong DB => gọi VNPT để lấy thông tin cơ bản
        try:
            bn = fetch_patient_by_code(patient_code, d_from, d_to)
        except Exception as e:
            # Lỗi kết nối/ cấu hình API
            messages.error(request, f"Lỗi lấy dữ liệu VNPT: {e}")
            return render(request, "health_record/main.html", {
                "patient": SimpleNamespace(ma_bn=patient_code, ho_ten="", ngay_sinh="", gioi_tinh="", phone="", dia_chi=""),
                "reports_json": "[]",
                "error": f"Lỗi lấy dữ liệu VNPT: {e}",
            })

        if not bn:
            # Không tìm thấy BN trong khoảng ngày
            return render(request, "health_record/main.html", {
                "patient": SimpleNamespace(ma_bn=patient_code, ho_ten="", ngay_sinh="", gioi_tinh="", phone="", dia_chi=""),
                "reports_json": "[]",
                "error": "Không tìm thấy thông tin bệnh nhân trong khoảng thời gian tra cứu.",
            })

        dob = parse_dob(bn.get("NGAYSINH"))
        patient = SimpleNamespace(
            id=None,
            ho_ten=(bn.get("TENBENHNHAN") or "").strip(),
            ngay_sinh=_fmt_dmy(dob) if dob else "",
            gioi_tinh=bn.get("GIOITINH") or bn.get("GIOI_TINH") or "",
            phone=bn.get("SDTBENHNHAN") or bn.get("SO_DIEN_THOAI") or "",
            dia_chi="",  # API không trả địa chỉ
            ma_bn=patient_code,
        )

    # 3) Lấy danh sách phiếu từ API viewreport (đã lọc bỏ 'Tóm tắt bệnh án')
    try:
        reports = get_patient_report(patient_code)  # trả list các dict
    except Exception as e:
        messages.warning(request, f"Không lấy được danh sách phiếu: {e}")
        reports = []

    # 4) (Tuỳ chọn) Chuẩn hoá tối thiểu cho frontend nếu cần
    # Ở đây mình giữ nguyên fields từ API để JS xử lý: TENDICHVU, URLFILE, NGAYKHAM, ...
    reports_json = json.dumps(reports, ensure_ascii=False)

    return render(request, "health_record/main.html", {
        "patient": patient,
        "reports_json": reports_json,  # JS trong template sẽ đọc biến này để render list/detail
        "error": None,
    })


# def view_patient_report(request, patient_code):
#     patient_id = request.session.get('patient_id')
#     if not patient_id:
#         return redirect('booking:patient_login')
#     patient = get_object_or_404(Patient, id=patient_id)

#     # So sánh patient_code trên URL với mã thực tế của patient đang đăng nhập
#     if patient_code.upper() != patient.ma_bn.upper():
#         # redirect về đúng hồ sơ:
#         return redirect('health_record:view_patient_report', patient_code=patient.ma_bn)
#     return render(request, "health_record/main.html", {
#         "patient": patient
#     })


## => demo
# from types import SimpleNamespace
# def view_patient_report(request, patient_code):
#     patient = SimpleNamespace(
#         id=1,
#         name="Nguyễn Văn Demo",
#         dob="1990-01-01",
#         gender="Nam",
#         phone="0901234567",
#         address="TP.HCM",
#         ma_bn="BN00000666",   # gán cố định để test
#     )
#     return render(request, "health_record/main.html", {
#         "patient": patient
#     })


# @patient_access_required
# def api_get_patient_list(request): # &&&&&&& => tiếp tục tối ưu sau
#     from_date = request.GET.get("from_date")
#     to_date = request.GET.get("to_date")

#     if from_date is None or to_date is None:
#         from_date_fmt = "01012025"
#         to_date_fmt = "27082025"
#     else:
#         from_date_fmt = parse_vn_date(from_date, "01012025")
#         to_date_fmt = parse_vn_date(to_date, "27082025")

#     url = "https://apibenhnhan.vncare.vn/patient_api/api/v3/patient/tracuu/dsbenhnhan"
#     headers = {
#         "Authorization": "848a33334bfdd253ba40adf0e8d6541cc5e9dc16a8956134edb9cefb92cf4f42",
#     }
#     params = {
#         "maCSYT": "79VMD",
#         "tuNgay": from_date_fmt,
#         "denNgay": to_date_fmt,
#     }

#     try:
#         response = requests.get(url, headers=headers, params=params, timeout=100)
#         response.raise_for_status()
#         data = response.json()

#         if data.get("errorCode") == 0:
#             patient_list = data.get("result", [])

#             # Đếm số lần mỗi bệnh nhân xuất hiện theo mã bệnh nhân
#             patient_counts = defaultdict(list)
#             for p in patient_list:
#                 ma_bn = p.get("MABENHNHAN")
#                 if ma_bn:
#                     patient_counts[ma_bn].append(p)

#             # Lọc ra các bệnh nhân có xuất hiện >1 lần
#             multi_visit_patients = [records for records in patient_counts.values() if len(records) > 1]
#             flat_multi_visit_patients = [p for group in multi_visit_patients for p in group]

#             return JsonResponse({
#                 "success": True,
#                 "patients": patient_list,
#                 "patients_multi_visit": flat_multi_visit_patients,
#             })

#         else:
#             error_message = data.get("errorMessage", "Lỗi không xác định.")
#             return JsonResponse({
#                 "success": False,
#                 "error": error_message,
#                 "patients": []
#             })
#     except requests.RequestException as e:
#         error_message = f"Lỗi kết nối API: {str(e)}"
#         return JsonResponse({
#             "success": False,
#             "error": error_message,
#             "patients": []
#         })


# def parse_vn_date(date_str, default):
#     try:
#         if "/" in date_str:
#             return datetime.strptime(date_str, "%d/%m/%Y").strftime("%d%m%Y")
#         elif len(date_str) == 8 and date_str.isdigit():
#             return date_str
#         else:
#             # Có thể xử lý các định dạng khác tại đây
#             return default
#     except Exception:
#         return default


# def get_patient_list(request):
#     # Có thể truyền ngày từ giao diện, hoặc dùng mặc định
#     from_date = request.GET.get("from_date")  # dạng ddMMyyyy
#     to_date = request.GET.get("to_date")

#     # Chuyển sang định dạng ddMMyyyy (API yêu cầu)
#     if from_date is None or to_date is None:
#         from_date_fmt = "01052025"
#         to_date_fmt = "01072025"
#     else:
#         from_date_fmt = parse_vn_date(from_date, "01052025")
#         to_date_fmt = parse_vn_date(to_date, "01072025")

#     # Gọi API VNCARE
#     url = "https://apibenhnhan.vncare.vn/patient_api/api/v3/patient/tracuu/dsbenhnhan"
#     headers = {
#         "Authorization": "848a33334bfdd253ba40adf0e8d6541cc5e9dc16a8956134edb9cefb92cf4f42",
#     }
#     params = {
#         "maCSYT": "79VMD",
#         "tuNgay": from_date_fmt,
#         "denNgay": to_date_fmt,
#     }

#     try:
#         response = requests.get(url, headers=headers, params=params, timeout=100)
#         response.raise_for_status()
#         data = response.json()

#         if data.get("errorCode") == 0:
#             patient_list = data.get("result", [])

#             # Đếm số lần mỗi bệnh nhân xuất hiện theo mã bệnh nhân
#             patient_counts = defaultdict(list)
#             for p in patient_list:
#                 ma_bn = p.get("MABENHNHAN")
#                 if ma_bn:
#                     patient_counts[ma_bn].append(p)

#             # Lọc ra các bệnh nhân có xuất hiện >1 lần (tức là khám nhiều lần)
#             multi_visit_patients = [records for records in patient_counts.values() if len(records) > 1]

#             # Flatten danh sách nếu muốn hiển thị
#             flat_multi_visit_patients = [p for group in multi_visit_patients for p in group]
#         else:
#             patient_list = []
#             error_message = data.get("errorMessage", "Lỗi không xác định.")
#             print("VNCARE API ERROR:", error_message)
#     except requests.RequestException as e:
#         patient_list = []
#         error_message = f"Lỗi kết nối API: {str(e)}"
#         print("VNCARE API ERROR:", error_message)

#     return render(request, "health_record/patient_list.html", {
#         "patients": patient_list,
#         "from_date": from_date,
#         "to_date": to_date,
#         "error": error_message if 'error_message' in locals() else None,
#     })