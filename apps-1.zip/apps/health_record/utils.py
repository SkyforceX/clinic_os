from collections import defaultdict
from urllib.parse import urljoin

from django.db.models import Q
# views.py
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.http import require_GET
from django.contrib.auth.decorators import login_required
from apps.patients.models import Patient
from crm import settings
from .models import PatientDocument
from apps.booking.models import HealthContract

@login_required
@require_GET
def ajax_patients_by_company(request):
    # => form upload patient doc
    company_id = request.GET.get('company_id')
    q = (request.GET.get('q') or '').strip()

    if not company_id:
        return JsonResponse({"results": []})

    qs = Patient.objects.filter(company_id=company_id)

    if q:
        qs = qs.filter(
            Q(ma_bn__icontains=q) |
            Q(ho_ten__icontains=q) |
            Q(phone__icontains=q)
        )

    qs = qs.order_by('id')
    if qs.count() > 1000:
        qs = qs[:1000]
    results = [
        {
            "id": p.id,
            "text": f"{p.ma_bn} – {p.ho_ten} – {p.ngay_sinh:%d/%m/%Y}" if p.ngay_sinh else f"{p.ma_bn} – {p.ho_ten}",
            "patient_code": p.ma_bn,
            "name": p.ho_ten,
            "dob": p.ngay_sinh.strftime('%d/%m/%Y') if p.ngay_sinh else ""
        }
        for p in qs
    ]
    return JsonResponse({"results": results})


def group_reports_by_name(reports):
    grouped = defaultdict(list)
    for report in reports:
        grouped[report['REPORT_NAME']].append(report)
    return grouped

#=============== ajax hiển thị iframe pdf ================#
ALLOWED_TYPES = {"paraclinical", "clinical"}

def _file_to_url(field) -> str | None:
    """
    Trả URL công khai của FileField (ưu tiên base_url của storage nếu có).
    """
    if not field:
        return None
    if not getattr(field, "name", ""):
        return None
    storage = field.storage
    base_url = getattr(storage, "base_url", settings.MEDIA_URL)
    # field.name là đường dẫn tương đối trong storage
    return urljoin(base_url, field.name)

def ajax_get_patient_doc_url(request):
    """
    Query params:
      - ma_bn: mã bệnh nhân (bắt buộc)
      - year: năm khám (tùy chọn; nếu không có -> lấy mới nhất)
      - doc_type: 'paraclinical' | 'clinical' (bắt buộc)
      - company_id: (tùy chọn) để ràng buộc đúng công ty
    """
    ma_bn = (request.GET.get("ma_bn") or "").strip()
    year = (request.GET.get("year") or "").strip()
    doc_type = (request.GET.get("doc_type") or "").strip()
    company_id = request.GET.get("company_id")

    if not ma_bn or doc_type not in ALLOWED_TYPES:
        return JsonResponse({"error": "Thiếu ma_bn hoặc doc_type không hợp lệ."}, status=400)

    patient_qs = Patient.objects.filter(ma_bn=ma_bn)
    if company_id:
        patient_qs = patient_qs.filter(company_id=company_id)

    patient = patient_qs.first()
    if not patient:
        return JsonResponse({"error": "Không tìm thấy bệnh nhân."}, status=404)

    docs = PatientDocument.objects.filter(patient=patient, doc_type=doc_type)
    if year.isdigit():
        docs = docs.filter(visit_date__year=int(year))

    doc = docs.order_by("-is_final", "-visit_date", "-created_at").first()
    if not doc or not doc.file:
        return JsonResponse({"url": None, "message": "Chưa có phiếu phù hợp."}, status=200)

    url = _file_to_url(doc.file)
    return JsonResponse({
        "url": url,
        "visit_date": doc.visit_date.strftime("%d/%m/%Y"),
        "is_final": doc.is_final,
        "doc_type": doc.doc_type,
        "patient_uuid": str(patient.uuid),
        "ma_bn": ma_bn,
    })