"""
Transitional model facade for contracts domain.

Ở bước refactor này:
- Contract vẫn dùng bảng/model legacy của apps.booking
- Quotation vẫn dùng bảng/model legacy của apps.booking
- Corporate profile vẫn dùng model hiện có của apps.contract
"""

from apps.booking.models import (
    HealthContract as Contract,
    ContractServiceDetail as ContractServiceLine,
    BloodCollectionInfo as BloodCollectionPlan,
    QuotationDraft,
    QuotationDraftDetail as QuotationLine,
)

from apps.contracts.domain.enums import ContractStatus

__all__ = [
    "Contract",
    "ContractServiceLine",
    "BloodCollectionPlan",
    "QuotationDraft",
    "QuotationLine",
    "ContractStatus",
]