from django.apps import AppConfig


class RbacConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rbac'


'''
định nghĩa role
map role → permission
policy helper dùng chung
object-level access rule
permission cho menu/UI
permission cho API
permission cho action nghiệp vụ
'''

'''
Super Admin
Manager
Sales
Điều dưỡng
Lễ tân
Bác sĩ
Kế toán
CSKH
Nhân sự công ty đối tác
Bệnh nhân
'''