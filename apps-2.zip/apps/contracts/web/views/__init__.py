from apps.contracts.web.views.catalog_views import *
from apps.contracts.web.views.contract_views import *
from apps.contracts.web.views.corporate_views import *
from apps.contracts.web.views.quotation_views import *