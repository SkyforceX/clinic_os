from django.urls import path

from apps.contracts.api.views import ajax_checkup_overview

app_name = "contracts_api"

urlpatterns = [
    path("checkup-overview/", ajax_checkup_overview, name="ajax_checkup_overview"),
]