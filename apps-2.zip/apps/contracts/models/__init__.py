"""
Transitional model facade for contracts domain.

Refactor hiện tại:
- Contract vẫn đang dùng bảng/model legacy của apps.booking
- Quotation vẫn đang dùng bảng/model legacy của apps.booking
- CorporateContractProfile đã được đưa về app mới apps.contracts
"""

from apps.booking.models import (
    HealthContract as Contract,
    ContractServiceDetail as ContractServiceLine,
    BloodCollectionInfo as BloodCollectionPlan,
    QuotationDraft,
    QuotationDraftDetail as QuotationLine,
)

from apps.contracts.domain.enums import ContractStatus
from apps.contracts.models.corporate import CorporateContractProfile

__all__ = [
    "Contract",
    "ContractServiceLine",
    "BloodCollectionPlan",
    "QuotationDraft",
    "QuotationLine",
    "CorporateContractProfile",
    "ContractStatus",
]