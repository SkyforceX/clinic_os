"""
Reserved for future backoffice schedule admin screens.

Các màn quản trị lịch kiểu calendar/month-limit có thể chuyển tiếp vào đây ở bước sau.
"""