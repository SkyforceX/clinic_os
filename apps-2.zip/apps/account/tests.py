import requests
from django.conf import settings
from django.shortcuts import render, redirect
from django.utils.dateparse import parse_date
from datetime import datetime
from collections import defaultdict
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404
from apps.external_api.client import get_patient_list


def parse_vn_date(date_str, default):
    try:
        if "/" in date_str:
            return datetime.strptime(date_str, "%d/%m/%Y").strftime("%d%m%Y")
        elif len(date_str) == 8 and date_str.isdigit():
            return date_str
        else:
            # Có thể xử lý các định dạng khác tại đây
            return default
    except Exception:
        return default


def view_patient_list(request):
    from_date = '01012025'
    to_date = '01082025'

    patient_list = get_patient_list(from_date, to_date)

     # Nhóm các lần khám theo mã bệnh nhân
    patient_counts = defaultdict(list)
    for p in patient_list:
        ma_bn = p.get("MABENHNHAN")
        if ma_bn:
            patient_counts[ma_bn].append(p)

    # Tạo danh sách nhóm đã sort theo số lần khám giảm dần
    grouped_patients = [
        {
            "ma_bn": ma_bn,
            "visits": visits,
            "count": len(visits)
        }
        for ma_bn, visits in patient_counts.items()
    ]
    grouped_patients.sort(key=lambda x: x["count"], reverse=True)

    # Lọc ra các bệnh nhân có xuất hiện >1 lần (tức là khám nhiều lần)
    multi_visit_patients = [records for records in patient_counts.values() if len(records) > 1]

    # Flatten danh sách nếu muốn hiển thị
    flat_multi_visit_patients = [p for group in multi_visit_patients for p in group]
    return render(request, "account/templates/account/test.html", {
        "patients": patient_list,
        "from_date": from_date,
        "to_date": to_date,
    })