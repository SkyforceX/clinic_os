from django.db import transaction
from django.utils import timezone
from apps.contract.models import Contract, ContractStatus
from apps.contract.policies import ContractPolicy


@transaction.atomic
def execute(*, contract: Contract, actor) -> Contract:
    if not ContractPolicy.can_approve(actor, contract):
        raise PermissionError("Bạn không có quyền duyệt hợp đồng.")

    if contract.status not in [ContractStatus.SUBMITTED, ContractStatus.DRAFT]:
        raise ValueError("Hợp đồng không ở trạng thái có thể duyệt.")

    contract.status = ContractStatus.APPROVED
    contract.approved_by = actor
    contract.approved_at = timezone.now()
    contract.save(update_fields=["status", "approved_by", "approved_at", "updated_at"])

    # TODO: audit log + domain event
    return contract