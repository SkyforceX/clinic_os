import json
import logging
import requests
from django.conf import settings

logger = logging.getLogger(__name__)

OLLAMA_BASE_URL = getattr(settings, "OLLAMA_BASE_URL", "http://127.0.0.1:11434")
OLLAMA_MODEL = getattr(settings, "OLLAMA_MODEL", "qwen2.5:3b")
OLLAMA_SYSTEM_PROMPT = getattr(
    settings,
    "OLLAMA_SYSTEM_PROMPT",
    (
        "Bạn là trợ lý nội bộ của phòng khám doanh nghiệp ClinicOS. "
        "Nhiệm vụ của bạn là hỗ trợ đội ngũ quản lý về nghiệp vụ khám sức khỏe doanh nghiệp, "
        "hợp đồng, báo giá, lên lịch, và các vấn đề vận hành. "
        "Luôn trả lời bằng tiếng Việt, ngắn gọn và chính xác."
    ),
)
OLLAMA_TIMEOUT = getattr(settings, "OLLAMA_TIMEOUT", 120)


def build_messages_payload(conversation_messages):
    """
    Chuyển danh sách Message objects thành payload cho OpenAI-compatible API.
    Tự động thêm system prompt ở đầu.
    """
    payload = [{"role": "system", "content": OLLAMA_SYSTEM_PROMPT}]
    for msg in conversation_messages:
        if msg.role in ("user", "assistant"):
            payload.append({"role": msg.role, "content": msg.content})
    return payload


def stream_completion(messages_payload):
    """
    Generator: stream từng delta token từ Ollama API.
    Yield từng chuỗi text nhỏ (delta content).
    Raise RuntimeError nếu kết nối thất bại.
    """
    url = f"{OLLAMA_BASE_URL}/v1/chat/completions"
    payload = {
        "model": OLLAMA_MODEL,
        "messages": messages_payload,
        "stream": True,
        "temperature": 0.7,
    }

    try:
        with requests.post(
            url, json=payload, stream=True, timeout=OLLAMA_TIMEOUT
        ) as response:
            response.raise_for_status()
            for raw_line in response.iter_lines():
                if not raw_line:
                    continue
                line = raw_line.decode("utf-8")
                if not line.startswith("data: "):
                    continue
                data_str = line[6:].strip()
                if data_str == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        yield content
                except (json.JSONDecodeError, IndexError, KeyError):
                    continue
    except requests.exceptions.ConnectionError as exc:
        logger.error("Không thể kết nối Ollama tại %s: %s", url, exc)
        raise RuntimeError(
            f"Không thể kết nối đến máy chủ AI ({OLLAMA_BASE_URL}). "
            "Vui lòng kiểm tra Ollama đang chạy."
        ) from exc
    except requests.exceptions.Timeout as exc:
        logger.error("Ollama timeout sau %ss", OLLAMA_TIMEOUT)
        raise RuntimeError("Máy chủ AI phản hồi quá lâu. Vui lòng thử lại.") from exc
    except requests.exceptions.HTTPError as exc:
        logger.error("Ollama HTTP error: %s", exc)
        raise RuntimeError(f"Lỗi máy chủ AI: {exc}") from exc


def complete_sync(messages_payload):
    """
    Gọi Ollama không stream, trả về toàn bộ nội dung phản hồi (str).
    Dùng khi cần lấy text đầy đủ (ví dụ: tự động đặt tiêu đề).
    """
    url = f"{OLLAMA_BASE_URL}/v1/chat/completions"
    payload = {
        "model": OLLAMA_MODEL,
        "messages": messages_payload,
        "stream": False,
        "temperature": 0.5,
        "max_tokens": 60,
    }
    try:
        response = requests.post(url, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as exc:
        logger.warning("Auto-title generation thất bại: %s", exc)
        return ""


def auto_generate_title(first_user_message: str) -> str:
    """
    Tự động tạo tiêu đề ngắn cho cuộc hội thoại dựa trên tin nhắn đầu tiên.
    """
    messages = [
        {
            "role": "system",
            "content": (
                "Tóm tắt nội dung câu hỏi sau thành một tiêu đề ngắn (tối đa 8 từ), "
                "chỉ trả về tiêu đề, không giải thích."
            ),
        },
        {"role": "user", "content": first_user_message},
    ]
    title = complete_sync(messages)
    return title[:200] if title else ""
