from apps.scheduling.web.urls import urlpatterns, app_name

__all__ = ["urlpatterns", "app_name"]