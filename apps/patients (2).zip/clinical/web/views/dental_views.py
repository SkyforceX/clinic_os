import json

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import render

from apps.clinical.policies import ClinicalPolicy
from apps.clinical.selectors.dental_selectors import (
    build_dental_exam_page_context,
    build_dental_result_payload,
)
from apps.clinical.services.dental_commands import save_dental_examination
from apps.patients.models import Patient


def _extract_tooth_data_from_mapping(mapping):
    tooth_data = {}

    for key, value in mapping.items():
        if value in (None, ""):
            continue

        if key.startswith("tooth_upper_"):
            tooth_no = key.replace("tooth_upper_", "").strip()
            if tooth_no:
                tooth_data[tooth_no] = str(value).strip()

        elif key.startswith("tooth_lower_"):
            tooth_no = key.replace("tooth_lower_", "").strip()
            if tooth_no:
                tooth_data[tooth_no] = str(value).strip()

    return tooth_data


def _build_payload_from_form(request):
    data = request.POST

    payload = {
        "patient_id": data.get("patient_id"),
        "dental_exam_id": data.get("dental_exam_id"),
        "company_id": data.get("company_id"),
        "additional_notes": data.get("additional_notes", ""),
        "tooth_loss_classification": data.get("missing_type", ""),
        "other_oral_conditions": data.get("other_oral_conditions", ""),
        "chewing_ability": data.get("chewing_ability", ""),
        "health_classification": data.get("health_classification", ""),
        "conclusion": data.get("conclusion", ""),
        "tooth_data": _extract_tooth_data_from_mapping(data),
    }
    return payload


def _get_request_payload(request):
    content_type = (request.content_type or "").lower()

    if "application/json" in content_type:
        try:
            raw = request.body.decode("utf-8") if request.body else "{}"
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ValueError("Payload JSON không hợp lệ.")
            payload["tooth_data"] = payload.get("tooth_data") or {}
            return payload
        except json.JSONDecodeError:
            raise ValueError("JSON không hợp lệ.")

    # FormData / multipart/form-data / application/x-www-form-urlencoded
    return _build_payload_from_form(request)


@login_required(login_url="authentication:staff_login")
def dental_exam_form(request):
    if not ClinicalPolicy.can_manage_dental(request.user):
        return render(
            request,
            "core/403.html",
            {"error_message": "Bạn không có quyền truy cập."},
            status=403,
        )

    context = build_dental_exam_page_context(actor=request.user)
    return render(request, "clinical/staff/dental_exam.html", context)


@login_required(login_url="authentication:staff_login")
def api_save_dental_exam(request):
    if request.method != "POST":
        return JsonResponse(
            {"status": "error", "message": "Phương thức không hợp lệ."},
            status=405,
        )

    if not ClinicalPolicy.can_manage_dental(request.user):
        return JsonResponse(
            {"status": "error", "message": "Không có quyền truy cập."},
            status=403,
        )

    try:
        payload = _get_request_payload(request)

        patient_id = payload.get("patient_id")
        if not patient_id:
            return JsonResponse(
                {"status": "error", "message": "Thiếu patient_id."},
                status=400,
            )

        exam = save_dental_examination(
            patient_id=patient_id,
            payload=payload,
        )

        return JsonResponse(
            {
                "status": "success",
                "message": "Lưu khám răng thành công.",
                "data": {
                    "id": exam.id,
                    "patient_id": exam.patient_id,
                },
            }
        )

    except Patient.DoesNotExist:
        return JsonResponse(
            {"status": "error", "message": "Không tìm thấy bệnh nhân."},
            status=404,
        )
    except Exception as exc:
        return JsonResponse(
            {"status": "error", "message": str(exc)},
            status=400,
        )


@login_required(login_url="authentication:staff_login")
def get_dental_data(request, patient_id):
    if not ClinicalPolicy.can_manage_dental(request.user):
        return JsonResponse(
            {"status": "error", "message": "Không có quyền truy cập."},
            status=403,
        )

    try:
        data = build_dental_result_payload(patient_id=patient_id)
        return JsonResponse({"status": "success", "data": data})
    except Patient.DoesNotExist:
        return JsonResponse(
            {"status": "error", "message": "Không tìm thấy bệnh nhân."},
            status=404,
        )
    except Exception as exc:
        return JsonResponse(
            {"status": "error", "message": str(exc)},
            status=400,
        )