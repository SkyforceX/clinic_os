from apps.clinical.models import DentalExamination, ToothNotation
from apps.organizations.selectors.company_selectors import list_companies_for_actor
from apps.patients.models import Patient


def _split_note_columns(notations, num_columns=3):
    notations = list(notations)
    if not notations:
        return [[] for _ in range(num_columns)]

    size = (len(notations) + num_columns - 1) // num_columns
    return [notations[i:i + size] for i in range(0, len(notations), size)]


def build_dental_exam_page_context(*, actor):
    companies = list_companies_for_actor(actor)
    notations = list(ToothNotation.objects.all().order_by("code"))
    notation_map = {item.code: item.description_vi for item in notations}

    tooth_upper = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28]
    tooth_lower = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38]

    return {
        "companies": companies,
        "notations": notations,
        "notation_map": notation_map,
        "note_columns": _split_note_columns(notations, num_columns=3),
        "tooth_upper": tooth_upper,
        "tooth_lower": tooth_lower,
    }


def build_dental_result_payload(*, patient_id):
    patient = Patient.objects.select_related("company").get(id=patient_id)
    dental_exam = (
        DentalExamination.objects.filter(patient=patient).order_by("-updated_at", "-id").first()
    )

    data = {
        "patient_id": patient.id,
        "dental_exam_id": dental_exam.id if dental_exam else "",
        "full_name": patient.ho_ten,
        "dob": patient.ngay_sinh.strftime("%d/%m/%Y") if patient.ngay_sinh else "",
        "gender": patient.gioi_tinh,
        "patient_code": patient.ma_bn,
        "loss_classification": dental_exam.tooth_loss_classification if dental_exam else "",
        "other_oral_conditions": dental_exam.other_oral_conditions if dental_exam else "",
        "chewing_ability": str(dental_exam.chewing_ability) if dental_exam and dental_exam.chewing_ability is not None else "",
        "health_classification": dental_exam.health_classification if dental_exam else "",
        "conclusion": dental_exam.conclusion if dental_exam else "",
        "tooth_details": {},
    }

    if dental_exam and dental_exam.tooth_data:
        for tooth, notation_code in dental_exam.tooth_data.items():
            try:
                tooth_num = int(tooth)
            except (TypeError, ValueError):
                continue
            prefix = "tooth_upper" if 11 <= tooth_num <= 28 else "tooth_lower"
            data["tooth_details"][f"{prefix}_{tooth}"] = notation_code

    return data