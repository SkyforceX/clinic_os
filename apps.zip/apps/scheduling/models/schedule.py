from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from apps.contract.models.corporate import CorporateContractProfile
from apps.contract.models.quotation import QuotationDraft


class TimeShift(models.TextChoices):
    MORNING = "morning", "Buổi sáng"
    AFTERNOON = "afternoon", "Buổi chiều"


class SlotType(models.TextChoices):
    WALKIN = "walkin", "Khách lẻ"
    CONTRACT = "contract", "Khách đoàn"


class ContractScheduleConfig(models.Model):
    quotation = models.OneToOneField(
        QuotationDraft,
        on_delete=models.CASCADE,
        related_name="schedule_config",
        verbose_name="Báo giá",
    )
    contract = models.OneToOneField(
        CorporateContractProfile,
        on_delete=models.SET_NULL,
        related_name="schedule_config",
        null=True,
        blank=True,
        verbose_name="Hợp đồng",
    )
    exam_start_date = models.DateField(verbose_name="Ngày bắt đầu khám")
    exam_end_date = models.DateField(verbose_name="Ngày kết thúc khám")
    planned_employee_count = models.PositiveIntegerField(
        default=0,
        verbose_name="Số khách hàng đăng ký",
    )
    am_capacity_limit = models.PositiveIntegerField(
        default=0,
        verbose_name="Giới hạn slot sáng",
    )
    pm_capacity_limit = models.PositiveIntegerField(
        default=0,
        verbose_name="Giới hạn slot chiều",
    )
    registered_by = models.ForeignKey(
        "auth.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="registered_contract_schedule_configs",
        verbose_name="Người đăng ký",
    )
    created_at = models.DateTimeField(null=True, blank=True, verbose_name="Ngày tạo")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Cập nhật lúc")

    class Meta:
        db_table = "contract_schedule_config"
        ordering = ["-updated_at", "-id"]
        indexes = [
            models.Index(fields=["quotation"], name="contract_sc_quotation_idx"),
            models.Index(fields=["contract"], name="contract_sc_contract_idx"),
            models.Index(
                fields=["exam_start_date", "exam_end_date"],
                name="contract_sc_exam_range_idx",
            ),
        ]
        constraints = [
            models.CheckConstraint(
                check=Q(planned_employee_count__gte=0),
                name="contract_schedule_cfg_employee_count_gte_0",
            ),
            models.CheckConstraint(
                check=Q(am_capacity_limit__gte=0),
                name="contract_schedule_cfg_am_limit_gte_0",
            ),
            models.CheckConstraint(
                check=Q(pm_capacity_limit__gte=0),
                name="contract_schedule_cfg_pm_limit_gte_0",
            ),
            models.CheckConstraint(
                check=Q(exam_end_date__gte=models.F("exam_start_date")),
                name="contract_schedule_cfg_end_date_gte_start_date",
            ),
        ]

    def clean(self):
        errors = {}

        if self.exam_start_date and self.exam_end_date:
            if self.exam_end_date < self.exam_start_date:
                errors["exam_end_date"] = "Ngày kết thúc khám phải lớn hơn hoặc bằng ngày bắt đầu khám."

        if self.planned_employee_count is not None and self.planned_employee_count < 0:
            errors["planned_employee_count"] = "Số khách hàng đăng ký phải lớn hơn hoặc bằng 0."

        if self.am_capacity_limit is not None and self.am_capacity_limit < 0:
            errors["am_capacity_limit"] = "Giới hạn slot sáng phải lớn hơn hoặc bằng 0."

        if self.pm_capacity_limit is not None and self.pm_capacity_limit < 0:
            errors["pm_capacity_limit"] = "Giới hạn slot chiều phải lớn hơn hoặc bằng 0."

        if self.contract_id:
            linked_quotation_id = getattr(self.contract, "quotation_id", None)
            if linked_quotation_id and linked_quotation_id != self.quotation_id:
                errors["contract"] = "Hợp đồng không thuộc báo giá đã chọn."

        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        self.full_clean()
        return super().save(*args, **kwargs)

    def __str__(self):
        if self.quotation_id and getattr(self.quotation, "company", None):
            company_name = getattr(self.quotation.company, "name", None) or getattr(
                self.quotation.company, "company_name", None
            )
            if company_name:
                return company_name
        return f"Lịch khám báo giá #{self.quotation_id}"


class ScheduleBloodCollectionRow(models.Model):
    schedule_config = models.ForeignKey(
        ContractScheduleConfig,
        on_delete=models.CASCADE,
        related_name="blood_collection_rows",
        verbose_name="Lịch đăng ký khám",
    )
    collection_date = models.DateField(verbose_name="Ngày lấy máu")
    location = models.CharField(
        max_length=255,
        blank=True,
        default="",
        verbose_name="Địa điểm",
    )
    people_count = models.PositiveIntegerField(default=0, verbose_name="Số khách hàng")
    staff_count = models.PositiveIntegerField(default=0, verbose_name="Số điều dưỡng")
    created_at = models.DateTimeField(null=True, blank=True, verbose_name="Ngày tạo")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Cập nhật lúc")

    class Meta:
        db_table = "schedule_blood_collection_row"
        ordering = ["collection_date", "id"]
        indexes = [
            models.Index(
                fields=["schedule_config", "collection_date"],
                name="sched_blood_cfg_date_idx",
            ),
            models.Index(
                fields=["collection_date"],
                name="sched_blood_date_idx",
            ),
        ]
        constraints = [
            models.CheckConstraint(
                check=Q(people_count__gte=0),
                name="sched_blood_people_gte_0",
            ),
            models.CheckConstraint(
                check=Q(staff_count__gte=0),
                name="sched_blood_staff_gte_0",
            ),
        ]

    def clean(self):
        errors = {}
        if self.people_count is not None and self.people_count < 0:
            errors["people_count"] = "Số khách hàng phải lớn hơn hoặc bằng 0."
        if self.staff_count is not None and self.staff_count < 0:
            errors["staff_count"] = "Số điều dưỡng phải lớn hơn hoặc bằng 0."
        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        self.full_clean()
        return super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.collection_date} - {self.location or 'Không rõ địa điểm'}"


class ScheduleSlot(models.Model):
    contract = models.ForeignKey(
        CorporateContractProfile,
        on_delete=models.CASCADE,
        related_name="schedule_slots",
        null=True,
        blank=True,
        verbose_name="Hợp đồng",
    )
    quotation = models.ForeignKey(
        QuotationDraft,
        on_delete=models.CASCADE,
        related_name="schedule_slots",
        null=True,
        blank=True,
        verbose_name="Báo giá",
    )
    date = models.DateField(verbose_name="Ngày")
    shift = models.CharField(
        max_length=20,
        choices=TimeShift.choices,
        verbose_name="Ca",
    )
    slot_type = models.CharField(
        max_length=20,
        choices=SlotType.choices,
        verbose_name="Loại slot",
    )
    capacity = models.PositiveIntegerField(default=0, verbose_name="Sức chứa")
    booked_count = models.PositiveIntegerField(default=0, verbose_name="Đã đặt")
    created_at = models.DateTimeField(null=True, blank=True, verbose_name="Ngày tạo")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Cập nhật lúc")
    
    class Meta:
        db_table = "schedule_slot"
        ordering = ["date", "shift", "id"]
        indexes = [
            models.Index(fields=["date", "shift"], name="schedule_sl_date_shift_idx"),
            models.Index(fields=["slot_type", "date"], name="schedule_sl_type_date_idx"),
            models.Index(
                fields=["contract", "date", "shift"],
                name="sched_sl_ct_dt_sf_idx",
            ),
            models.Index(
                fields=["quotation", "date", "shift"],
                name="sched_sl_qt_dt_sf_idx",
            ),
        ]
        constraints = [
            models.CheckConstraint(
                check=Q(capacity__gte=0),
                name="schedule_slot_capacity_gte_0",
            ),
            models.CheckConstraint(
                check=Q(booked_count__gte=0),
                name="schedule_slot_booked_count_gte_0",
            ),
            models.CheckConstraint(
                check=Q(capacity__gte=models.F("booked_count")),
                name="schedule_slot_capacity_gte_booked_count",
            ),
            models.CheckConstraint(
                check=(
                    (Q(contract__isnull=False) & Q(slot_type=SlotType.CONTRACT))
                    | Q(contract__isnull=True)
                ),
                name="schedule_slot_contract_requires_contract_type",
            ),
            models.CheckConstraint(
                check=(
                    Q(contract__isnull=False)
                    | Q(quotation__isnull=False)
                    | Q(slot_type=SlotType.WALKIN)
                ),
                name="schedule_slot_owner_required_for_contract_slots",
            ),
            models.CheckConstraint(
                check=~(
                    Q(contract__isnull=True)
                    & Q(quotation__isnull=True)
                    & Q(slot_type=SlotType.CONTRACT)
                ),
                name="schedule_slot_contract_type_must_have_owner",
            ),
            models.UniqueConstraint(
                fields=["date", "shift", "slot_type", "contract"],
                condition=Q(contract__isnull=False),
                name="uq_schedule_slot_date_shift_type_contract_nonnull",
            ),
            models.UniqueConstraint(
                fields=["date", "shift", "slot_type", "quotation"],
                condition=Q(contract__isnull=True, quotation__isnull=False),
                name="uq_schedule_slot_date_shift_type_quotation_when_no_contract",
            ),
        ]

    def clean(self):
        errors = {}

        if self.capacity is not None and self.capacity < 0:
            errors["capacity"] = "Sức chứa phải lớn hơn hoặc bằng 0."

        if self.booked_count is not None and self.booked_count < 0:
            errors["booked_count"] = "Số đã đặt phải lớn hơn hoặc bằng 0."

        if (
            self.capacity is not None
            and self.booked_count is not None
            and self.booked_count > self.capacity
        ):
            errors["capacity"] = "Sức chứa không được nhỏ hơn số đã đặt."

        if self.slot_type == SlotType.CONTRACT:
            if not self.contract_id and not self.quotation_id:
                errors["contract"] = "Slot khách đoàn phải gắn hợp đồng hoặc báo giá."

            if self.contract_id and self.quotation_id:
                linked_quotation_id = getattr(self.contract, "quotation_id", None)
                if linked_quotation_id and linked_quotation_id != self.quotation_id:
                    errors["quotation"] = "Báo giá không khớp với hợp đồng của slot."
        else:
            if self.contract_id:
                errors["contract"] = "Slot khách lẻ không được gắn hợp đồng."
            if self.quotation_id:
                errors["quotation"] = "Slot khách lẻ không được gắn báo giá."

        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        self.full_clean()
        return super().save(*args, **kwargs)

    @property
    def remaining_capacity(self):
        return max(0, (self.capacity or 0) - (self.booked_count or 0))

    def __str__(self):
        if self.contract_id:
            owner = f"contract={self.contract_id}"
        elif self.quotation_id:
            owner = f"quotation={self.quotation_id}"
        else:
            owner = "walkin"
        return f"{self.date} {self.shift} {self.slot_type} {owner}"