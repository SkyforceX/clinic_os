import json
import os
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import FileResponse, Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.template.loader import render_to_string
from django.views.decorators.http import require_POST

from apps.contract.policies import ContractPolicy
from apps.contract.models.document import IssuedDocument
from apps.contract.models.quotation import QuotationDraft, QuotationLine
from apps.contract.services.document_payloads import build_quotation_preview_context
from apps.contract.services.quotation_documents import (
    get_latest_issued_quotation_document,
    issue_quotation_document,
)
from apps.organizations.services.company_commands import upsert_company_from_quotation
from apps.contract.models import CorporateContractProfile

# ── catalog ──────────────────────────────────────────────────────────────────
#
# NGUỒN DỮ LIỆU: DB (CheckupCategory + GroupCheckup), KHÔNG phải catalog.json.
#
# Root cause đã fix:
#   Trước đây load_catalog() đọc từ static/contract/data/catalog.json — file
#   tĩnh không tự đồng bộ với DB. Khi admin thêm/sửa/sắp xếp nhóm qua
#   GroupCheckup.display_order, modal vẫn hiển thị theo thứ tự vật lý trong
#   JSON → nhóm sai thứ tự, items lẫn nhóm nếu file JSON bị chỉnh tay.
#
#   Fix: load_catalog() nay query CheckupCategory, order_by đúng thứ tự:
#     1. group_checkup__display_order  (thứ tự nhóm theo admin)
#     2. group_checkup__name           (tiebreak alphabet)
#     3. display_order                 (thứ tự item trong nhóm)
#     4. id                            (tiebreak stable)
#
#   item["id"] = int(item_code) nếu có (= JSON id cũ → tương thích
#   QuotationLine.catalog_id đang lưu trong DB), fallback = CheckupCategory.pk.
#
from apps.catalogs.models import CheckupCategory  # noqa: E402


def load_catalog():
    """
    Trả về flat list các catalog item dict, đã sort đúng thứ tự:
      group.display_order → group.name → item.display_order → item.id

    Format mỗi item tương thích 100% với CATALOG_JSON cũ mà JS đang dùng.

    item["id"] = int(item_code) nếu item_code là số (tương thích catalog_id
    đã lưu trong QuotationLine), fallback = CheckupCategory.pk nếu item_code
    trống hoặc không phải số.
    """
    qs = (
        CheckupCategory.objects
        .filter(is_active=True)
        .select_related("group_checkup")
        .order_by(
            "group_checkup__display_order",
            "group_checkup__name",
            "display_order",
            "id",
        )
    )

    result = []
    for cat in qs:
        group = cat.group_checkup

        # Dùng item_code (= JSON id cũ, dạng string "1","2",...) để giữ
        # catalog_id tương thích với các QuotationLine đã lưu trước đây.
        # Nếu item_code trống hoặc không phải số nguyên → dùng pk.
        try:
            item_id = int(cat.item_code) if cat.item_code else cat.id
        except (ValueError, TypeError):
            item_id = cat.id

        result.append({
            "id":                  item_id,
            "group":               group.name,
            "group_en":            group.group_en or "",
            "subgroup":            cat.subgroup_name or None,
            "name":                cat.item_name,
            "description":         cat.description or "",
            "price_type":          cat.price_type,
            "list_price":          int(cat.list_price or 0),
            "price_male":          int(cat.price_male or 0),
            "price_female_single": int(cat.price_female_single or 0),
            "price_female_family": int(cat.price_female_family or 0),
            "for_male":            bool(cat.for_male),
            "for_female_single":   bool(cat.for_female_single),
            "for_female_family":   bool(cat.for_female_family),
            "note":                cat.note or "",
        })
    return result


def group_catalog(catalog):
    """
    Gom nhóm flat catalog list thành:
      { group_name: {"items": [...], "subgroups": {subgroup_name: [...]}} }

    Vì catalog đã sort theo group.display_order từ load_catalog(), thứ tự
    của dict này cũng đúng (Python 3.7+ dict là insertion-ordered).
    """
    groups = {}
    for item in catalog:
        if not isinstance(item, dict):
            continue
        group    = item.get("group") or "Khác"
        subgroup = item.get("subgroup") or ""
        groups.setdefault(group, {"items": [], "subgroups": {}})
        if subgroup:
            groups[group]["subgroups"].setdefault(subgroup, []).append(item)
        else:
            groups[group]["items"].append(item)
    return groups


# ─────────────────────────────────────────────────────────────────────────────

def quotation_queryset_for_user(user):
    qs = QuotationDraft.objects.select_related(
        "created_by",
        "company",
        "corporate_contract_profile__contract",
    )
    if ContractPolicy.is_manager(user):
        return qs
    return qs.filter(created_by=user)


def get_quotation_for_user_or_404(user, quotation_id):
    return get_object_or_404(quotation_queryset_for_user(user), pk=quotation_id)


def latest_quotation_ids_by_company():
    return {
        q.company_id: q.id
        for q in (
            QuotationDraft.objects
            .filter(company__isnull=False)
            .order_by("company_id", "-created_at", "-id")
            .distinct("company_id")
        )
    }


def decorate_quotation_contract_state(quotation):
    linked_profile = getattr(quotation, "corporate_contract_profile", None)
    linked_contract = getattr(linked_profile, "contract", None) if linked_profile else None
    quotation.linked_contract = linked_contract
    quotation.has_contract = linked_contract is not None
    quotation.is_latest_for_company = False

    latest_map = latest_quotation_ids_by_company()
    if quotation.company_id:
        quotation.is_latest_for_company = latest_map.get(quotation.company_id) == quotation.id

    return quotation


def safe_decimal(raw):
    if raw in (None, "", "None"):
        return None
    try:
        return Decimal(str(raw).replace(",", "").strip())
    except (InvalidOperation, ValueError):
        return None


def safe_int(raw, default=0):
    try:
        return int(raw or 0)
    except (TypeError, ValueError):
        return default


def fmt_vnd(v):
    if v in (None, "", 0):
        return "0"
    return f"{int(v):,}".replace(",", ".")


def file_response(field_file):
    if not field_file or not field_file.name:
        raise Http404("Tệp chưa được tạo.")
    filename = os.path.basename(field_file.name)
    return FileResponse(field_file.open("rb"), as_attachment=True, filename=filename)


# ── list ─────────────────────────────────────────────────────────────────────

@login_required(login_url="authentication:staff_login")
def quotation_list(request):
    quotations = list(
        quotation_queryset_for_user(request.user)
        .order_by("-created_at")
    )

    latest_map = latest_quotation_ids_by_company()

    from apps.approvals.models import ApprovalRequest, ApprovalStatus
    quotation_ids = [q.pk for q in quotations]
    pending_map = {
        ar.quotation_id: ar
        for ar in ApprovalRequest.objects.filter(
            quotation_id__in=quotation_ids,
            status=ApprovalStatus.PENDING,
        )
    }

    for q in quotations:
        linked_profile = getattr(q, "corporate_contract_profile", None)
        linked_contract = getattr(linked_profile, "contract", None) if linked_profile else None
        q.linked_contract = linked_contract
        q.has_contract = linked_contract is not None
        q.is_latest_for_company = bool(q.company_id and latest_map.get(q.company_id) == q.id)
        q.pending_ar = pending_map.get(q.pk)

    return render(
        request,
        "contract/staff/quotation_list.html",
        {
            "quotations": quotations,
            "is_manager": ContractPolicy.is_manager(request.user),
        },
    )


# ── edit form ─────────────────────────────────────────────────────────────────

@login_required(login_url="authentication:staff_login")
def edit_quotation(request, quotation_id):
    quotation = get_quotation_for_user_or_404(request.user, quotation_id)
    quotation = decorate_quotation_contract_state(quotation)

    if quotation.is_locked:
        messages.error(request, "Báo giá này đã bị khóa.")
        return redirect("contract:quotation_preview", quotation_id=quotation.id)

    if quotation.has_contract:
        messages.error(request, "Báo giá này đã phát sinh hợp đồng nên không thể sửa trực tiếp.")
        return redirect("contract:quotation_preview", quotation_id=quotation.id)

    # ── catalog từ DB, đã sort đúng thứ tự ────────────────────────────────
    catalog = load_catalog()
    groups  = group_catalog(catalog)

    # ── Build existing_lines_json: full snapshot keyed by catalog_id ──────────
    # JS dùng để: (1) restore checkbox states, (2) override data-cat giá gốc
    # từ snapshot thay vì từ catalog hiện tại → độc lập DB catalog.
    existing_lines = {}
    for line in quotation.lines.order_by("display_order"):
        if line.catalog_id is None:
            continue
        existing_lines[str(line.catalog_id)] = {
            "selected": True,
            # checkbox states
            "checked_male": bool(line.checked_male),
            "checked_fs":   bool(line.checked_female_single),
            "checked_ff":   bool(line.checked_female_family),
            # final prices (đã tính discount)
            "price_male": int(line.price_male or 0),
            "price_fs":   int(line.price_female_single or 0),
            "price_ff":   int(line.price_female_family or 0),
            # giá ưu đãi (sau toolbar %, trước row %)
            "udai_male": int(line.udai_price_male or 0),
            "udai_fs":   int(line.udai_price_fs   or 0),
            "udai_ff":   int(line.udai_price_ff   or 0),
            # row-level discount %
            "pct_male": float(line.discount_male_pct or 0),
            "pct_fs":   float(line.discount_fs_pct   or 0),
            "pct_ff":   float(line.discount_ff_pct   or 0),
            # snapshot: gender applicability
            "for_m":  bool(line.for_male),
            "for_fs": bool(line.for_female_single),
            "for_ff": bool(line.for_female_family),
        }

    return render(
        request,
        "contract/staff/edit_quotation.html",
        {
            "quotation":            quotation,
            "groups":               groups,
            "catalog_json":         json.dumps(catalog,         ensure_ascii=False),
            "existing_lines_json":  json.dumps(existing_lines,  ensure_ascii=False),
            "commission_sale_pct":      float(quotation.commission_sale_pct      or 0),
            "commission_co_pct":        float(quotation.commission_co_pct        or 0),
            "commission_sale_amount":   int(quotation.commission_sale_amount or 0),
            "commission_co_amount":     int(quotation.commission_co_amount   or 0),
        },
    )


# ── create form ───────────────────────────────────────────────────────────────

@login_required(login_url="authentication:staff_login")
def create_proposal(request):
    # ── catalog từ DB, đã sort đúng thứ tự ────────────────────────────────
    catalog = load_catalog()
    groups  = group_catalog(catalog)
    default_valid_until = (date.today() + timedelta(days=30)).isoformat()

    return render(
        request,
        "contract/staff/create_proposal.html",
        {
            "groups":               groups,
            "catalog_json":         json.dumps(catalog, ensure_ascii=False),
            "default_valid_until":  default_valid_until,
        },
    )


# ── save ─────────────────────────────────────────────────────────────────────

@login_required(login_url="authentication:staff_login")
@require_POST
@transaction.atomic
def save_quotation(request):
    post = request.POST

    company_name = (post.get("company_name") or "").strip()
    if not company_name:
        messages.error(request, "Vui lòng nhập tên công ty.")
        return redirect("contract:create_proposal")

    quotation_id = post.get("quotation_id")

    # ── Edit mode: snapshot existing lines trước khi xóa ─────────────────────
    # Giữ lại metadata (item_name, description, group, ...) độc lập với catalog
    # hiện tại. Khi tái tạo dòng, ưu tiên dùng snapshot nếu có.
    snapshot_map = {}  # catalog_id (int) -> QuotationLine

    if quotation_id:
        quotation = get_quotation_for_user_or_404(request.user, quotation_id)
        quotation = decorate_quotation_contract_state(quotation)

        if quotation.is_locked:
            messages.error(request, "Báo giá này đã bị khóa.")
            return redirect("contract:quotation_preview", quotation_id=quotation.id)

        if quotation.has_contract:
            messages.error(request, "Báo giá này đã phát sinh hợp đồng nên không thể sửa.")
            return redirect("contract:quotation_preview", quotation_id=quotation.id)

        for line in quotation.lines.all():
            if line.catalog_id is not None:
                snapshot_map[int(line.catalog_id)] = line

        quotation.lines.all().delete()
    else:
        quotation = QuotationDraft()

    company_address = (post.get("company_address") or "").strip()

    company = upsert_company_from_quotation(
        actor=request.user,
        name=company_name,
        address=company_address,
        company=quotation.company if quotation.pk else None,
    )

    quotation.created_by      = request.user
    quotation.company         = company
    quotation.company_name    = company.name
    quotation.company_address = company.address or ""

    quotation.contact_name = (post.get("contact_name") or "").strip()
    quotation.note         = (post.get("note")         or "").strip()

    try:
        quotation.valid_until = date.fromisoformat(post.get("valid_until") or "")
    except (ValueError, TypeError):
        quotation.valid_until = date.today() + timedelta(days=30)

    quotation.pax_from            = safe_int(post.get("pax_from"), 0) or None
    quotation.male_count          = safe_int(post.get("male_count"), 0)
    quotation.female_single_count = safe_int(post.get("female_single_count"), 0)
    quotation.female_family_count = safe_int(post.get("female_family_count"), 0)

    quotation.discount_male_pct = safe_decimal(post.get("discount_male_pct")) or 0
    quotation.discount_fs_pct   = safe_decimal(post.get("discount_fs_pct"))   or 0
    quotation.discount_ff_pct   = safe_decimal(post.get("discount_ff_pct"))   or 0

    quotation.commission_sale_pct    = safe_decimal(post.get("commission_sale_pct"))
    quotation.commission_sale_amount = safe_decimal(post.get("commission_sale_amount"))
    quotation.commission_co_pct      = safe_decimal(post.get("commission_co_pct"))
    quotation.commission_co_amount   = safe_decimal(post.get("commission_co_amount"))
    quotation.save()

    # ── catalog_map để fallback metadata khi không có snapshot ────────────
    # Dùng DB (cùng nguồn với load_catalog() ở view) thay vì JSON.
    # Key = str(item["id"]) để khớp với selected_ids từ form (string).
    catalog     = load_catalog()
    catalog_map = {
        str(item["id"]): item
        for item in catalog
        if isinstance(item, dict) and "id" in item
    }

    lines = []
    selected_ids = post.getlist("selected_ids")

    for order, cid in enumerate(selected_ids):
        try:
            cid_int = int(cid)
        except (ValueError, TypeError):
            continue

        snap = snapshot_map.get(cid_int)   # dữ liệu đã lưu (nếu có)
        cat  = catalog_map.get(str(cid))   # dữ liệu catalog hiện tại (fallback)

        if snap is None and cat is None:
            continue

        checked_male = f"checked_male_{cid}" in post
        checked_fs   = f"checked_fs_{cid}"   in post
        checked_ff   = f"checked_ff_{cid}"   in post

        if not (checked_male or checked_fs or checked_ff):
            continue

        # ── Metadata: ưu tiên snapshot, fallback catalog ──────────────────
        item_name     = (snap.item_name     if snap else None) or (cat.get("name",        "") if cat else "")
        description   = (snap.description   if snap else None) or (cat.get("description", "") if cat else "")
        group_name    = (snap.group_name    if snap else None) or (cat.get("group",        "") if cat else "")
        subgroup_name = (snap.subgroup_name if snap else None) or ((cat.get("subgroup") or "") if cat else "")
        list_price_v  = snap.list_price if snap else safe_decimal(cat.get("list_price") if cat else None)
        price_type_v  = (snap.price_type if snap else None) or (cat.get("price_type", "standard") if cat else "standard")
        note_v        = (snap.note        if snap else None) or ((cat.get("note") or "") if cat else "")

        # gender applicability: ưu tiên snapshot, fallback catalog
        for_m  = snap.for_male          if snap else (cat.get("for_male",          True)  if cat else True)
        for_fs = snap.for_female_single if snap else (cat.get("for_female_single", True)  if cat else True)
        for_ff = snap.for_female_family if snap else (cat.get("for_female_family", True)  if cat else True)

        # ── Prices từ form (JS đã tính) ───────────────────────────────────
        def price_val(key):
            raw = post.get(f"price_{key}_{cid}")
            d = safe_decimal(raw)
            if d is None and cat:
                d = safe_decimal(cat.get(f"price_{key}"))
            return d

        line = QuotationLine(
            quotation=quotation,
            catalog_id=cid_int,
            item_name=item_name,
            description=description,
            group_name=group_name,
            subgroup_name=subgroup_name,
            list_price=list_price_v,
            price_type=price_type_v,
            note=note_v,
            for_male=for_m,
            for_female_single=for_fs,
            for_female_family=for_ff,
            # Giá ưu đãi (sau toolbar %, trước row %)
            udai_price_male=safe_decimal(post.get(f"udai_male_{cid}")) if checked_male else None,
            udai_price_fs=safe_decimal(post.get(f"udai_fs_{cid}"))     if checked_fs   else None,
            udai_price_ff=safe_decimal(post.get(f"udai_ff_{cid}"))     if checked_ff   else None,
            # % giảm từng dòng
            discount_male_pct=safe_decimal(post.get(f"pct_male_{cid}")) or 0,
            discount_fs_pct=safe_decimal(post.get(f"pct_fs_{cid}"))     or 0,
            discount_ff_pct=safe_decimal(post.get(f"pct_ff_{cid}"))     or 0,
            # Giá cuối (JS computed)
            price_male=price_val("male")          if checked_male else None,
            price_female_single=price_val("female_single") if checked_fs   else None,
            price_female_family=price_val("female_family") if checked_ff   else None,
            checked_male=checked_male,
            checked_female_single=checked_fs,
            checked_female_family=checked_ff,
            display_order=order,
        )
        lines.append(line)

    if not lines:
        quotation.delete()
        messages.error(request, "Chưa chọn dịch vụ nào.")
        return redirect("contract:create_proposal")

    QuotationLine.objects.bulk_create(lines)
    messages.success(request, "Đã lưu báo giá.")
    return redirect("contract:quotation_preview", quotation_id=quotation.pk)


# ── preview ──────────────────────────────────────────────────────────────────

@login_required(login_url="authentication:staff_login")
def quotation_preview(request, quotation_id):
    quotation = get_quotation_for_user_or_404(request.user, quotation_id)
    quotation = decorate_quotation_contract_state(quotation)

    context = build_quotation_preview_context(quotation)
    context["quotation"]         = quotation
    context["latest_issued"]     = get_latest_issued_quotation_document(quotation)
    context["linked_contract"]   = quotation.linked_contract
    context["can_edit_quotation"] = (not quotation.is_locked) and (not quotation.has_contract)
    context["can_issue_document"] = not quotation.is_locked

    from apps.approvals.models import ApprovalRequest, ApprovalStatus
    from apps.approvals.policies import ApprovalPolicy
    pending_ar = (
        ApprovalRequest.objects
        .filter(quotation=quotation, status=ApprovalStatus.PENDING)
        .first()
    )
    context["pending_ar"]   = pending_ar
    context["can_submit_approval"] = (
        quotation.status == "DRAFT"
        and not quotation.is_locked
        and not quotation.has_contract
    )
    context["can_direct_approve"] = bool(
        pending_ar and ApprovalPolicy.can_approve(request.user, pending_ar)
    )
    context["submit_approval_url"] = (
        f"/contract/quotations/{quotation.pk}/submit-approval/"
    )
    return render(request, "contract/staff/quotation_preview.html", context)


# ── issue docx/pdf ───────────────────────────────────────────────────────────

@login_required(login_url="authentication:staff_login")
@require_POST
def issue_quotation_document_view(request, quotation_id):
    quotation = get_quotation_for_user_or_404(request.user, quotation_id)
    quotation = decorate_quotation_contract_state(quotation)

    if quotation.is_locked:
        messages.error(request, "Báo giá đã bị khóa, không thể phát hành lại tài liệu.")
        return redirect("contract:quotation_preview", quotation_id=quotation.pk)

    try:
        issued = issue_quotation_document(
            quotation=quotation,
            actor=request.user,
            request=request,
        )
    except Exception as exc:
        messages.error(request, f"Không thể phát hành tài liệu: {exc}")
        return redirect("contract:quotation_preview", quotation_id=quotation.pk)

    if issued.pdf_file:
        messages.success(request, "Đã phát hành báo giá PDF.")
    else:
        messages.warning(
            request,
            "PDF chưa được tạo, đang dùng fallback hoặc thiếu công cụ chuyển đổi.",
        )

    return redirect("contract:quotation_preview", quotation_id=quotation.pk)


@login_required(login_url="authentication:staff_login")
def download_issued_quotation_docx(request, issued_id):
    issued = get_object_or_404(
        IssuedDocument,
        pk=issued_id,
        doc_type=IssuedDocument.DOC_TYPE_QUOTATION,
    )
    return file_response(issued.docx_file)


@login_required(login_url="authentication:staff_login")
def download_issued_quotation_pdf(request, issued_id):
    issued = get_object_or_404(
        IssuedDocument,
        pk=issued_id,
        doc_type=IssuedDocument.DOC_TYPE_QUOTATION,
    )
    return file_response(issued.pdf_file)


# ── pdf export fallback ───────────────────────────────────────────────────────

@login_required(login_url="authentication:staff_login")
def quotation_pdf(request):
    quotation_id = request.GET.get("id")
    quotation    = get_quotation_for_user_or_404(request.user, quotation_id)

    latest_issued = get_latest_issued_quotation_document(quotation)
    if latest_issued and latest_issued.pdf_file:
        return file_response(latest_issued.pdf_file)

    context = build_quotation_preview_context(quotation)
    context["quotation"] = quotation
    context["today"]     = date.today()

    html_string = render_to_string(
        "contract/staff/quotation_pdf.html",
        context,
        request=request,
    )

    try:
        import weasyprint
        pdf_bytes = weasyprint.HTML(
            string=html_string,
            base_url=request.build_absolute_uri("/"),
        ).write_pdf()
        filename = f"bao-gia-{quotation.company_name}-{quotation.pk}.pdf"
        response = HttpResponse(pdf_bytes, content_type="application/pdf")
        response["Content-Disposition"] = f'attachment; filename="{filename}"'
        return response
    except ImportError:
        return HttpResponse(html_string, content_type="text/html; charset=utf-8")


# ── delete ───────────────────────────────────────────────────────────────────

@login_required(login_url="authentication:staff_login")
def delete_quotation(request, pk):
    quotation = get_quotation_for_user_or_404(request.user, pk)
    quotation = decorate_quotation_contract_state(quotation)

    if quotation.has_contract:
        messages.error(request, "Báo giá này đã phát sinh hợp đồng nên không thể xóa.")
        return redirect("contract:quotation_preview", quotation_id=quotation.id)

    if quotation.is_locked:
        messages.error(request, "Báo giá này đã bị khóa nên không thể xóa.")
        return redirect("contract:quotation_preview", quotation_id=quotation.id)

    if request.method == "POST":
        quotation.delete()
        messages.success(request, "Đã xóa báo giá.")
        return redirect("contract:quotation_list")

    return render(
        request,
        "contract/staff/quotation_confirm_delete.html",
        {"quotation": quotation},
    )
