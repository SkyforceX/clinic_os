from django import forms

from apps.hrm.models.department import Department, Position
from apps.hrm.models.employee import Employee, EmploymentType, GenderChoice


class DepartmentForm(forms.ModelForm):
    class Meta:
        model = Department
        fields = ["name", "code", "description", "parent", "is_active", "display_order"]
        widgets = {
            "name":        forms.TextInput(attrs={"class": "form-control"}),
            "code":        forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "parent":      forms.Select(attrs={"class": "form-select"}),
            "display_order": forms.NumberInput(attrs={"class": "form-control"}),
        }


class PositionForm(forms.ModelForm):
    class Meta:
        model = Position
        fields = ["name", "code", "department", "level", "is_active"]
        widgets = {
            "name":       forms.TextInput(attrs={"class": "form-control"}),
            "code":       forms.TextInput(attrs={"class": "form-control"}),
            "department": forms.Select(attrs={"class": "form-select"}),
            "level":      forms.NumberInput(attrs={"class": "form-control"}),
        }


class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = [
            # Định danh
            "employee_code", "full_name", "gender", "date_of_birth",
            "phone", "email", "address",
            # Pháp lý
            "id_card_number", "id_card_issued_date", "id_card_issued_by",
            "tax_code", "social_insurance_code",
            "bank_account", "bank_name",
            # Công việc
            "department", "position", "direct_manager",
            "employment_type", "hire_date", "probation_end_date", "official_date",
            # Liên hệ khẩn cấp
            "emergency_contact_name", "emergency_contact_phone", "emergency_contact_rel",
            # Khác
            "note",
        ]
        widgets = {
            "employee_code":    forms.TextInput(attrs={"class": "form-control"}),
            "full_name":        forms.TextInput(attrs={"class": "form-control"}),
            "gender":           forms.Select(attrs={"class": "form-select"}),
            "date_of_birth":    forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "phone":            forms.TextInput(attrs={"class": "form-control"}),
            "email":            forms.EmailInput(attrs={"class": "form-control"}),
            "address":          forms.Textarea(attrs={"class": "form-control", "rows": 2}),
            "id_card_number":   forms.TextInput(attrs={"class": "form-control"}),
            "id_card_issued_date": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "id_card_issued_by":   forms.TextInput(attrs={"class": "form-control"}),
            "tax_code":             forms.TextInput(attrs={"class": "form-control"}),
            "social_insurance_code": forms.TextInput(attrs={"class": "form-control"}),
            "bank_account":     forms.TextInput(attrs={"class": "form-control"}),
            "bank_name":        forms.TextInput(attrs={"class": "form-control"}),
            "department":       forms.Select(attrs={"class": "form-select"}),
            "position":         forms.Select(attrs={"class": "form-select"}),
            "direct_manager":   forms.Select(attrs={"class": "form-select"}),
            "employment_type":  forms.Select(attrs={"class": "form-select"}),
            "hire_date":        forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "probation_end_date": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "official_date":    forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "emergency_contact_name":  forms.TextInput(attrs={"class": "form-control"}),
            "emergency_contact_phone": forms.TextInput(attrs={"class": "form-control"}),
            "emergency_contact_rel":   forms.TextInput(attrs={"class": "form-control"}),
            "note":             forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Chỉ chọn quản lý đang active
        from apps.hrm.models.employee import EmployeeStatus
        self.fields["direct_manager"].queryset = Employee.objects.filter(
            status__in=[EmployeeStatus.ACTIVE, EmployeeStatus.PROBATION]
        ).order_by("full_name")
        self.fields["direct_manager"].empty_label = "— Không có —"
        self.fields["department"].empty_label = "— Chọn phòng ban —"
        self.fields["position"].empty_label = "— Chọn chức vụ —"


class TransferForm(forms.Form):
    """Form chuyển bộ phận / chức vụ."""

    new_position = forms.ModelChoiceField(
        queryset=Position.objects.filter(is_active=True).order_by("name"),
        label="Chức vụ mới",
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    new_department = forms.ModelChoiceField(
        queryset=Department.objects.filter(is_active=True).order_by("name"),
        label="Phòng ban mới",
        required=False,
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    note = forms.CharField(
        label="Lý do / Ghi chú",
        required=False,
        widget=forms.Textarea(attrs={"class": "form-control", "rows": 3}),
    )


class OffboardForm(forms.Form):
    """Form nghỉ việc."""

    resignation_date = forms.DateField(
        label="Ngày nghỉ việc",
        widget=forms.DateInput(attrs={"class": "form-control", "type": "date"}),
    )
    terminate = forms.BooleanField(
        label="Chấm dứt hợp đồng (không phải tự nghỉ)",
        required=False,
        widget=forms.CheckboxInput(attrs={"class": "form-check-input"}),
    )
    reason = forms.CharField(
        label="Lý do",
        required=False,
        widget=forms.Textarea(attrs={"class": "form-control", "rows": 3}),
    )
