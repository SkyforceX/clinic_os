from django import template

register = template.Library()


@register.filter(name="in_group")
def in_group(user, group_name):
    """
    Kiểm tra user có thuộc group_name hay không.
    Dùng trong template:
        {% if request.user|in_group:"HR Admin" %}
    """
    if not user or not getattr(user, "is_authenticated", False):
        return False
    if not group_name:
        return False
    return user.groups.filter(name=group_name).exists()