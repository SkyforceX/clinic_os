"""
Management command: seed_positions
====================================
Seed dữ liệu mẫu cho Phòng ban, Chức vụ và PositionGroupMapping
phù hợp với mô hình hoạt động phòng khám clinic_os.

Chạy SAU khi seed_groups đã chạy:

    python manage.py seed_groups
    python manage.py seed_positions
    python manage.py seed_positions --dry-run

Idempotent: get_or_create → an toàn khi chạy nhiều lần.
"""

from __future__ import annotations

import textwrap

from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand
from django.db import transaction


# ─── Cấu hình Phòng ban ──────────────────────────────────────────────────────
#
# (code, name, parent_code_or_None, display_order)

DEPARTMENTS = [
    ("BGD",  "Ban Giám đốc",             None,  1),
    ("KD",   "Phòng Kinh doanh",         None,  2),
    ("NS",   "Phòng Nhân sự",            None,  3),
    ("LS",   "Khoa Lâm sàng",            None,  4),
    ("XN",   "Khoa Xét nghiệm",          None,  5),
    ("CDHA", "Khoa Chẩn đoán hình ảnh", None,  6),
    ("KT",   "Phòng Kế toán",            None,  7),
    ("CNTT", "Phòng Công nghệ thông tin",None,  8),
    ("QLCL", "Phòng Quản lý chất lượng", None,  9),
    ("RD",   "Bộ phận Tiếp nhận",        None, 10),
]


# ─── Cấu hình Chức vụ ────────────────────────────────────────────────────────
#
# (code, name, department_code, level)
# level: 1=nhân viên, 3=tổ trưởng, 5=trưởng phòng, 7=phó GĐ, 9=GĐ

POSITIONS = [
    # Ban Giám đốc
    ("GD",      "Giám đốc",                         "BGD", 9),
    ("PGD",     "Phó Giám đốc",                     "BGD", 7),

    # Kinh doanh
    ("TPKD",   "Trưởng phòng Kinh doanh",           "KD",  5),
    ("NVKD",   "Nhân viên Kinh doanh",              "KD",  1),

    # Nhân sự
    ("TPNS",   "Trưởng phòng Nhân sự",              "NS",  5),
    ("NVNS",   "Nhân viên Nhân sự (HR Admin)",      "NS",  1),

    # Lâm sàng
    ("TBSLS",  "Trưởng khoa Lâm sàng",              "LS",  5),
    ("BS",     "Bác sĩ",                            "LS",  3),
    ("DD",     "Điều dưỡng / Y tá",                 "LS",  1),

    # Xét nghiệm
    ("TBSXN",  "Trưởng khoa Xét nghiệm",            "XN",  5),
    ("KTXN",   "Kỹ thuật viên Xét nghiệm",          "XN",  1),

    # CĐHA
    ("TBSCDHA","Trưởng khoa CĐHA",                  "CDHA",5),
    ("KTCDHA", "Kỹ thuật viên CĐHA",               "CDHA",1),

    # Kế toán
    ("TPKT",   "Trưởng phòng Kế toán",              "KT",  5),
    ("NVKT",   "Kế toán viên",                      "KT",  1),

    # CNTT
    ("TPCNTT", "Trưởng phòng CNTT",                 "CNTT",5),
    ("DEVCNTT","Lập trình viên",                    "CNTT",1),

    # Quản lý chất lượng
    ("QLCL",   "Chuyên viên Quản lý chất lượng",   "QLCL",3),

    # Tiếp nhận
    ("NVTN",   "Nhân viên Tiếp nhận",               "RD",  1),
]


# ─── Ánh xạ Chức vụ → Django Group ──────────────────────────────────────────
#
# (position_code, [group_name, ...])
# Group name phải khớp với seed_groups.py

MAPPINGS = [
    ("GD",      ["Executives"]),
    ("PGD",     ["Executives", "Managers"]),
    ("TPKD",    ["Managers", "Sales Team"]),
    ("NVKD",    ["Sales Team"]),
    ("TPNS",    ["Managers", "HR Admin"]),
    ("NVNS",    ["HR Admin"]),
    ("TBSLS",   ["Managers", "Doctor"]),
    ("BS",      ["Doctor"]),
    ("DD",      ["Nurses"]),
    ("TBSXN",   ["Managers", "Doctor"]),
    ("KTXN",    ["Nurses"]),
    ("TBSCDHA", ["Managers", "Doctor"]),
    ("KTCDHA",  ["Nurses"]),
    ("TPKT",    ["Managers", "Accountants"]),
    ("NVKT",    ["Accountants"]),
    ("TPCNTT",  ["Managers"]),
    ("DEVCNTT", []),            # CNTT: không cấp group mặc định, tự gán thủ công
    ("QLCL",    ["Quality"]),
    ("NVTN",    ["Nurses"]),
]


class Command(BaseCommand):
    help = textwrap.dedent("""\
        Seed Phòng ban, Chức vụ và PositionGroupMapping mẫu cho clinic_os.
        Chạy sau seed_groups.
    """)

    def add_arguments(self, parser):
        parser.add_argument(
            "--dry-run",
            action="store_true",
            default=False,
            help="Xem trước, không lưu vào database.",
        )

    def handle(self, *args, **options):
        dry_run  = options["dry_run"]
        verbose  = options["verbosity"]

        if dry_run:
            self.stdout.write(self.style.WARNING("⚠  DRY-RUN – không lưu.\n"))

        dept_map     = {}
        position_map = {}

        with transaction.atomic():
            # ── 1. Phòng ban ──────────────────────────────────────────────────
            self.stdout.write("── Phòng ban ──")
            for code, name, parent_code, order in DEPARTMENTS:
                parent = dept_map.get(parent_code) if parent_code else None
                obj, created = self._get_or_create_dept(code, name, parent, order)
                dept_map[code] = obj
                label = "TẠO" if created else "OK"
                if verbose >= 1:
                    self.stdout.write(f"  [{label}] {name}")

            # ── 2. Chức vụ ────────────────────────────────────────────────────
            self.stdout.write("\n── Chức vụ ──")
            for code, name, dept_code, level in POSITIONS:
                dept = dept_map.get(dept_code)
                obj, created = self._get_or_create_pos(code, name, dept, level)
                position_map[code] = obj
                label = "TẠO" if created else "OK"
                if verbose >= 1:
                    self.stdout.write(f"  [{label}] {name}")

            # ── 3. PositionGroupMapping ───────────────────────────────────────
            self.stdout.write("\n── PositionGroupMapping ──")
            from apps.hrm.models.access_control import PositionGroupMapping

            for pos_code, group_names in MAPPINGS:
                pos = position_map.get(pos_code)
                if not pos:
                    continue
                for gname in group_names:
                    grp = Group.objects.filter(name=gname).first()
                    if not grp:
                        self.stdout.write(
                            self.style.WARNING(
                                f"  [SKIP] Group '{gname}' chưa tồn tại "
                                f"(chạy seed_groups trước)"
                            )
                        )
                        continue
                    _, created = PositionGroupMapping.objects.get_or_create(
                        position=pos, django_group=grp
                    )
                    label = "TẠO" if created else "OK"
                    if verbose >= 1:
                        self.stdout.write(f"  [{label}] {pos.name} → {gname}")

            if dry_run:
                transaction.set_rollback(True)

        self.stdout.write(self.style.SUCCESS("\n✔  seed_positions hoàn tất."))
        if dry_run:
            self.stdout.write(self.style.WARNING("⚠  DRY-RUN – đã rollback."))

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _get_or_create_dept(code, name, parent, order):
        from apps.hrm.models.department import Department
        return Department.objects.get_or_create(
            code=code,
            defaults={
                "name":          name,
                "parent":        parent,
                "display_order": order,
                "is_active":     True,
            },
        )

    @staticmethod
    def _get_or_create_pos(code, name, dept, level):
        from apps.hrm.models.department import Position
        return Position.objects.get_or_create(
            code=code,
            defaults={
                "name":       name,
                "department": dept,
                "level":      level,
                "is_active":  True,
            },
        )
